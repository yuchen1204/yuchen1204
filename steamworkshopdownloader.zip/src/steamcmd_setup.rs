//! steamcmd 自动获取：缺失时从 Steam 官方地址下载并解压到 exe 旁的 steamcmd 目录

use std::io::Read;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::Sender;

use crate::downloader::{TaskState, WorkerMsg};

/// steamcmd 官方 Windows 版压缩包
const STEAMCMD_URL: &str = "https://steamcdn-a.akamaihd.net/client/installer/steamcmd.zip";

/// exe 旁的固定安装目录；返回 exe 所在目录下的 steamcmd/
pub fn install_dir() -> Option<PathBuf> {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|d| d.join("steamcmd")))
}

/// 安装后 steamcmd.exe 的预期路径
pub fn expected_exe_path() -> Option<PathBuf> {
    install_dir().map(|d| d.join("steamcmd.exe"))
}

/// 确保 steamcmd 可用：
/// - exe 已存在 → 直接返回其路径
/// - 未配置/不存在 → 自动安装到 exe 旁 steamcmd 目录并返回路径
/// 全程通过 tx 发进度消息（idx 固定 0，列表尚未展示时仅日志可见）
pub fn ensure_steamcmd(
    configured: &Path,
    tx: &Sender<WorkerMsg>,
    cancelled: &AtomicBool,
) -> Result<PathBuf, String> {
    if configured.exists() {
        return Ok(configured.to_path_buf());
    }

    // 已自动安装过 → 复用
    if let Some(p) = expected_exe_path() {
        if p.exists() {
            return Ok(p);
        }
    }

    let dir = install_dir().ok_or("无法确定程序所在目录")?;
    tx.send(WorkerMsg::Progress(
        0,
        TaskState::Downloading,
        0.0,
        "未检测到 steamcmd，正在从 Steam 官方下载…".into(),
    ))
    .ok();

    download_and_install(&dir, tx, cancelled)?;
    let exe = dir.join("steamcmd.exe");
    if !exe.exists() {
        return Err("下载完成但未找到 steamcmd.exe".into());
    }
    tx.send(WorkerMsg::Progress(
        0,
        TaskState::Downloading,
        100.0,
        "steamcmd 准备就绪".into(),
    ))
    .ok();
    Ok(exe)
}

/// 下载 zip → 解压 → 清理临时文件
fn download_and_install(dir: &Path, tx: &Sender<WorkerMsg>, cancelled: &AtomicBool) -> Result<(), String> {
    std::fs::create_dir_all(dir).map_err(|e| format!("创建目录失败: {e}"))?;

    // 已有残留的 zip 直接删掉重下，避免半截文件
    let zip_path = dir.join("steamcmd.zip");
    let _ = std::fs::remove_file(&zip_path);

    let resp = ureq::get(STEAMCMD_URL)
        .timeout(std::time::Duration::from_secs(300))
        .call()
        .map_err(|e| format!("下载 steamcmd 失败: {e}"))?;

    let total = resp
        .header("Content-Length")
        .and_then(|v| v.parse::<f64>().ok());

    let file = std::fs::File::create(&zip_path).map_err(|e| format!("写入文件失败: {e}"))?;
    let mut writer = std::io::BufWriter::new(file);
    let mut reader = resp.into_reader();
    let mut buf = [0u8; 64 * 1024];
    let mut got: u64 = 0;
    let mut last_pct = 0u8;
    loop {
        if cancelled.load(Ordering::SeqCst) {
            return Err("已取消".into());
        }
        match reader.read(&mut buf) {
            Ok(0) => break,
            Ok(n) => {
                std::io::Write::write_all(&mut writer, &buf[..n])
                    .map_err(|e| format!("写入文件失败: {e}"))?;
                got += n as u64;
                if let Some(total) = total {
                    let pct = ((got as f64 / total) * 100.0).min(100.0) as u8;
                    if pct > last_pct {
                        last_pct = pct;
                        tx.send(WorkerMsg::Progress(
                            0,
                            TaskState::Downloading,
                            pct as f32,
                            format!("下载 steamcmd… {pct}%"),
                        ))
                        .ok();
                    }
                }
            }
            Err(e) => return Err(format!("下载中断: {e}")),
        }
    }
    std::io::Write::flush(&mut writer).map_err(|e| format!("写入文件失败: {e}"))?;
    drop(writer);

    tx.send(WorkerMsg::Progress(
        0,
        TaskState::Downloading,
        100.0,
        "下载完成，正在解压…".into(),
    ))
    .ok();
    extract_zip(&zip_path, dir)?;
    let _ = std::fs::remove_file(&zip_path);
    Ok(())
}

/// 解压 zip 内全部条目到 dir（steamcmd.zip 无子目录结构，直接平铺）
fn extract_zip(zip_path: &Path, dir: &Path) -> Result<(), String> {
    let file = std::fs::File::open(zip_path).map_err(|e| format!("打开压缩包失败: {e}"))?;
    let mut archive = zip::ZipArchive::new(std::io::BufReader::new(file))
        .map_err(|e| format!("读取压缩包失败: {e}"))?;
    for i in 0..archive.len() {
        let mut entry = archive
            .by_index(i)
            .map_err(|e| format!("读取压缩包条目失败: {e}"))?;
        if entry.is_dir() {
            continue;
        }
        // 拒绝路径穿越条目
        let Some(name) = entry.enclosed_name().map(|p| p.to_path_buf()) else {
            continue;
        };
        let out_path = dir.join(name);
        if let Some(parent) = out_path.parent() {
            std::fs::create_dir_all(parent).map_err(|e| format!("创建目录失败: {e}"))?;
        }
        let mut out = std::fs::File::create(&out_path).map_err(|e| format!("创建文件失败: {e}"))?;
        std::io::copy(&mut entry, &mut out).map_err(|e| format!("解压失败: {e}"))?;
    }
    Ok(())
}
