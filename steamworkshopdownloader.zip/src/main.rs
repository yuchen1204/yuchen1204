#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use eframe::egui;
use std::path::{Path, PathBuf};

mod config;
mod downloader;
mod steamcmd_setup;

use downloader::{Downloader, TaskState, WorkerMsg};

// ── 现代暗黑主题配色方案 ──
const BG: egui::Color32 = egui::Color32::from_rgb(18, 18, 20); // 整体背景
const PANEL: egui::Color32 = egui::Color32::from_rgb(24, 24, 27); // 顶底栏
const BORDER: egui::Color32 = egui::Color32::from_rgb(45, 45, 48); // 边框
const CARD: egui::Color32 = egui::Color32::from_rgb(32, 32, 36); // 卡片背景
const CARD_HOVER: egui::Color32 = egui::Color32::from_rgb(38, 38, 42); // 卡片悬浮
const BTN: egui::Color32 = egui::Color32::from_rgb(50, 50, 55); // 按钮默认
const BTN_HOVER: egui::Color32 = egui::Color32::from_rgb(70, 70, 75); // 按钮悬浮
const INPUT_BG: egui::Color32 = egui::Color32::from_rgb(14, 14, 15); // 输入框
const TEXT: egui::Color32 = egui::Color32::from_rgb(240, 240, 240); // 主要文字
const DIM: egui::Color32 = egui::Color32::from_rgb(150, 150, 160); // 次要文字
const ACCENT: egui::Color32 = egui::Color32::from_rgb(37, 138, 255); // 强调色 (蓝)
const SUCCESS: egui::Color32 = egui::Color32::from_rgb(46, 204, 113); // 成功 (绿)
const ERROR: egui::Color32 = egui::Color32::from_rgb(231, 76, 60); // 错误 (红)
const WARN: egui::Color32 = egui::Color32::from_rgb(241, 196, 15); // 警告 (黄)

fn main() -> Result<(), eframe::Error> {
    let options = eframe::NativeOptions {
        viewport: egui::ViewportBuilder::default()
            .with_title("Steam 创意工坊下载器")
            .with_inner_size([900.0, 720.0])
            .with_min_inner_size([720.0, 550.0])
            .with_transparent(true),
        ..Default::default()
    };

    eframe::run_native(
        "Steam 创意工坊下载器",
        options,
        Box::new(|cc| Ok(Box::new(App::new(cc)))),
    )
}

fn configure_style(ctx: &egui::Context) {
    ctx.style_mut(|style| {
        let v = &mut style.visuals;
        v.dark_mode = true;
        v.window_fill = BG;
        v.panel_fill = BG;
        v.extreme_bg_color = INPUT_BG;
        v.hyperlink_color = ACCENT;
        v.selection.bg_fill = ACCENT.gamma_multiply(0.4);
        v.selection.stroke.color = TEXT;
        v.override_text_color = Some(TEXT);

        // 细阴影和现代圆角
        v.window_shadow = egui::epaint::Shadow {
            offset: [0, 4],
            blur: 12,
            spread: 0,
            color: egui::Color32::from_black_alpha(80),
        };

        let stroke = egui::Stroke::new(1.0_f32, BORDER);
        v.widgets.noninteractive.bg_stroke = stroke;
        v.widgets.noninteractive.fg_stroke = egui::Stroke::new(1.0_f32, TEXT);
        v.widgets.noninteractive.corner_radius = egui::CornerRadius::same(8);

        // 按钮圆角与颜色
        v.widgets.inactive.bg_fill = BTN;
        v.widgets.inactive.weak_bg_fill = BTN;
        v.widgets.inactive.fg_stroke = egui::Stroke::new(1.0_f32, TEXT);
        v.widgets.inactive.bg_stroke = egui::Stroke::NONE;
        v.widgets.inactive.corner_radius = egui::CornerRadius::same(8);

        v.widgets.hovered.bg_fill = BTN_HOVER;
        v.widgets.hovered.weak_bg_fill = BTN_HOVER;
        v.widgets.hovered.fg_stroke = egui::Stroke::new(1.0_f32, TEXT);
        v.widgets.hovered.bg_stroke = egui::Stroke::NONE;
        v.widgets.hovered.corner_radius = egui::CornerRadius::same(8);

        v.widgets.active.bg_fill = ACCENT.gamma_multiply(0.8);
        v.widgets.active.weak_bg_fill = ACCENT.gamma_multiply(0.8);
        v.widgets.active.fg_stroke = egui::Stroke::new(1.0_f32, TEXT);
        v.widgets.active.bg_stroke = egui::Stroke::NONE;
        v.widgets.active.corner_radius = egui::CornerRadius::same(8);

        // 滚动条样式
        style.spacing.scroll = egui::style::ScrollStyle {
            bar_width: 6.0,
            bar_inner_margin: 0.0,
            bar_outer_margin: 2.0,
            floating_allocated_width: 8.0,
            floating_width: 6.0,
            foreground_color: true,
            ..Default::default()
        };
        style.spacing.item_spacing = egui::vec2(10.0, 10.0);
    });
}

#[derive(Clone, Copy, PartialEq)]
enum PathRow {
    Steamcmd,
    DownloadDir,
}

#[derive(Debug, Clone)]
struct Task {
    workshop_id: String,
    app_id: String,
    dest_dir: PathBuf,
    state: TaskState,
    progress: f32,
    last_line: String,
}

struct App {
    config_path: PathBuf,
    steamcmd_path: PathBuf,
    download_dir: PathBuf,
    recent_app_ids: Vec<String>,
    app_id_input: String,
    workshop_input: String,
    tasks: Vec<Task>,
    downloader: Downloader,
    running: bool,
    toast: Option<(String, std::time::Instant)>,
}

impl App {
    fn new(cc: &eframe::CreationContext<'_>) -> Self {
        let exe_dir = std::env::current_exe()
            .ok()
            .and_then(|p| p.parent().map(PathBuf::from))
            .unwrap_or_else(|| PathBuf::from("."));
        let config_path = exe_dir.join("config.json");

        let (steamcmd_path, download_dir, recent) =
            config::Config::load(&config_path).map_or_else(
                || (exe_dir.join("steamcmd.exe"), PathBuf::from("."), Vec::new()),
                |cfg| (cfg.steamcmd_path, cfg.download_dir, cfg.recent_app_ids),
            );

        let app = Self {
            config_path,
            steamcmd_path,
            download_dir,
            recent_app_ids: recent,
            app_id_input: String::new(),
            workshop_input: String::new(),
            tasks: Vec::new(),
            downloader: Downloader::new(),
            running: false,
            toast: None,
        };

        // 载入系统中文字体
        let mut fonts = egui::FontDefinitions::default();
        for path in [
            r"C:\Windows\Fonts\msyh.ttc",
            r"C:\Windows\Fonts\simhei.ttf",
            r"C:\Windows\Fonts\simsun.ttc",
        ] {
            if let Ok(bytes) = std::fs::read(path) {
                let name = std::path::Path::new(path)
                    .file_stem()
                    .and_then(|s| s.to_str())
                    .unwrap_or("cnfont")
                    .to_string();
                fonts
                    .font_data
                    .insert(name.clone(), egui::FontData::from_owned(bytes).into());
                fonts
                    .families
                    .entry(egui::FontFamily::Proportional)
                    .or_default()
                    .insert(0, name);
                break;
            }
        }
        cc.egui_ctx.set_fonts(fonts);
        configure_style(&cc.egui_ctx);

        app
    }

    fn save_config(&self) {
        let c = config::Config {
            steamcmd_path: self.steamcmd_path.clone(),
            download_dir: self.download_dir.clone(),
            recent_app_ids: self.recent_app_ids.clone(),
        };
        c.save(&self.config_path);
    }

    fn toast(&mut self, s: impl Into<String>) {
        self.toast = Some((s.into(), std::time::Instant::now()));
    }

    fn clear_finished(&mut self) {
        self.tasks
            .retain(|t| matches!(t.state, TaskState::Pending | TaskState::Downloading));
    }

    fn start_all(&mut self) {
        if self.running {
            return;
        }
        let app_id = self.app_id_input.trim().to_string();
        if !app_id.is_empty() && !app_id.chars().all(|c| c.is_ascii_digit()) {
            self.toast("AppID 必须是纯数字（留空则自动识别）");
            return;
        }

        let ids = config::parse_workshop_ids_bulk(&self.workshop_input);
        let fresh: Vec<String> = ids
            .into_iter()
            .filter(|id| !self.tasks.iter().any(|t| &t.workshop_id == id))
            .collect();
        if !fresh.is_empty() {
            let dest = self.download_dir.clone();
            for id in &fresh {
                self.tasks.push(Task {
                    workshop_id: id.clone(),
                    app_id: app_id.clone(),
                    dest_dir: dest.clone(),
                    state: TaskState::Pending,
                    progress: 0.0,
                    last_line: String::new(),
                });
            }
            self.workshop_input.clear();
        }

        let jobs = self
            .tasks
            .iter()
            .filter(|t| t.state == TaskState::Pending)
            .map(|t| (t.workshop_id.clone(), t.app_id.clone(), t.dest_dir.clone()))
            .collect::<Vec<_>>();
        if jobs.is_empty() {
            self.toast("没有可下载的任务");
            return;
        }

        if !app_id.is_empty() && !self.recent_app_ids.iter().any(|x| x == &app_id) {
            self.recent_app_ids.push(app_id);
            if self.recent_app_ids.len() > 8 {
                self.recent_app_ids.remove(0);
            }
        }
        self.save_config();

        self.running = true;
        self.downloader.start(jobs, self.steamcmd_path.clone());
    }
}

impl eframe::App for App {
    fn update(&mut self, ctx: &egui::Context, _frame: &mut eframe::Frame) {
        loop {
            match self.downloader.poll() {
                Some(WorkerMsg::Progress(idx, state, progress, line)) => {
                    if let Some(t) = self.tasks.get_mut(idx) {
                        t.state = state;
                        t.progress = progress;
                        t.last_line = line;
                    }
                }
                Some(WorkerMsg::AppIdResolved(idx, id)) => {
                    if let Some(t) = self.tasks.get_mut(idx) {
                        t.app_id = id;
                    }
                }
                Some(WorkerMsg::Finished) => {
                    self.running = false;
                    self.toast("全部任务已结束");
                }
                None => break,
            }
        }

        if let Some((_, t0)) = &self.toast {
            if t0.elapsed().as_secs_f32() >= 5.0 {
                self.toast = None;
            }
        }

        self.render_top(ctx);
        self.render_bottom(ctx);
        self.render_center(ctx);

        if self.running {
            ctx.request_repaint_after(std::time::Duration::from_millis(300));
        }
    }
}

impl App {
    fn render_top(&mut self, ctx: &egui::Context) {
        egui::TopBottomPanel::top("top")
            .frame(
                egui::Frame::new()
                    .fill(PANEL)
                    .inner_margin(egui::Margin::symmetric(24, 20))
                    .shadow(egui::epaint::Shadow {
                        offset: [0, 2],
                        blur: 6,
                        spread: 0,
                        color: egui::Color32::from_black_alpha(30),
                    }),
            )
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    ui.vertical(|ui| {
                        ui.heading(
                            egui::RichText::new("Steam 创意工坊下载器")
                                .size(22.0f32)
                                .color(TEXT)
                                .strong(),
                        );
                        ui.add_space(4.0);
                        ui.label(
                            egui::RichText::new("高效批量下载 · 自动识别游戏")
                                .size(13.0f32)
                                .color(DIM),
                        );
                    });
                    
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        let icon = egui::RichText::new("🎮").size(32.0);
                        ui.label(icon);
                    });
                });
            });
    }

    fn render_bottom(&mut self, ctx: &egui::Context) {
        egui::TopBottomPanel::bottom("bottom")
            .frame(
                egui::Frame::new()
                    .fill(PANEL)
                    .inner_margin(egui::Margin::symmetric(16, 20))
                    .shadow(egui::epaint::Shadow {
                        offset: [0, -2],
                        blur: 6,
                        spread: 0,
                        color: egui::Color32::from_black_alpha(30),
                    }),
            )
            .show(ctx, |ui| {
                ui.horizontal(|ui| {
                    if let Some((t, _)) = &self.toast {
                        ui.label(
                            egui::RichText::new(format!("🔔 {}", t))
                                .color(WARN)
                                .size(13.0)
                        );
                    }
                    
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if ui
                            .add(
                                egui::Button::new(
                                    egui::RichText::new("📂 打开下载目录")
                                        .size(13.0f32)
                                        .color(TEXT),
                                )
                                .fill(BTN)
                                .min_size(egui::vec2(120.0, 36.0)),
                            )
                            .clicked()
                        {
                            let _ = open::that_detached(&self.download_dir);
                        }
                        
                        if !self.running {
                            if ui
                                .add(
                                    egui::Button::new(
                                        egui::RichText::new("🧹 清空列表")
                                            .size(13.0f32)
                                            .color(TEXT),
                                    )
                                    .fill(BTN)
                                    .min_size(egui::vec2(100.0, 36.0)),
                                )
                                .clicked()
                            {
                                self.tasks.clear();
                            }
                            if ui
                                .add(
                                    egui::Button::new(
                                        egui::RichText::new("✨ 清除已完成")
                                            .size(13.0f32)
                                            .color(TEXT),
                                    )
                                    .fill(BTN)
                                    .min_size(egui::vec2(110.0, 36.0)),
                                )
                                .clicked()
                            {
                                self.clear_finished();
                            }
                        } else {
                            if ui
                                .add(
                                    egui::Button::new(
                                        egui::RichText::new("🛑 停止下载")
                                            .size(14.0)
                                            .strong()
                                            .color(TEXT),
                                    )
                                    .fill(ERROR.gamma_multiply(0.8))
                                    .min_size(egui::vec2(120.0, 36.0)),
                                )
                                .clicked()
                            {
                                self.downloader.cancel();
                                self.toast("正在停止…");
                            }
                        }
                    });
                });
            });
    }

    fn render_center(&mut self, ctx: &egui::Context) {
        egui::CentralPanel::default()
            .frame(egui::Frame::new().fill(BG).inner_margin(egui::Margin::same(20)))
            .show(ctx, |ui| {
                // ── 上半部分：配置与输入 ──
                ui.vertical(|ui| {
                    ui.spacing_mut().item_spacing = egui::vec2(0.0, 16.0);
                    
                    // 1. 基础设置卡片
                    egui::Frame::new()
                        .fill(CARD)
                        .corner_radius(egui::CornerRadius::same(12))
                        .stroke(egui::Stroke::new(1.0_f32, BORDER))
                        .inner_margin(egui::Margin::same(16))
                        .show(ui, |ui| {
                            ui.set_width(ui.available_width());
                            ui.label(egui::RichText::new("⚙ 基础设置").size(15.0).strong().color(TEXT));
                            ui.add_space(12.0);
                            
                            // SteamCMD 路径与下载目录并排？或者也上下排。
                            // 上下排更宽敞
                            ui.horizontal(|ui| {
                                // 使得标签有固定宽度，方便对齐
                                ui.add_sized([80.0, 32.0], egui::Label::new(egui::RichText::new("SteamCMD").size(13.0).color(DIM)));
                                
                                let mut path_text = shorten_path(&self.steamcmd_path, 60);
                                let bad = !self.steamcmd_path.exists();
                                
                                ui.add_sized(
                                    [ui.available_width() - 80.0, 32.0],
                                    egui::TextEdit::singleline(&mut path_text)
                                        .interactive(false)
                                        .text_color(if bad { ERROR } else { TEXT })
                                );
                                if ui.add_sized([60.0, 32.0], egui::Button::new("浏览")).clicked() {
                                    if let Some(p) = rfd::FileDialog::new()
                                        .add_filter("steamcmd", &["exe"])
                                        .set_title("选择 steamcmd.exe")
                                        .pick_file()
                                    {
                                        self.steamcmd_path = p;
                                        self.save_config();
                                    }
                                }
                                if bad {
                                    ui.label(egui::RichText::new("⚠️ 未找到，将自动下载").size(12.0).color(WARN));
                                }
                            });
                            
                            ui.add_space(8.0);
                            
                            ui.horizontal(|ui| {
                                ui.add_sized([80.0, 32.0], egui::Label::new(egui::RichText::new("下载目录").size(13.0).color(DIM)));
                                
                                let mut path_text = shorten_path(&self.download_dir, 60);
                                ui.add_sized(
                                    [ui.available_width() - 80.0, 32.0],
                                    egui::TextEdit::singleline(&mut path_text)
                                        .interactive(false)
                                );
                                if ui.add_sized([60.0, 32.0], egui::Button::new("浏览")).clicked() {
                                    if let Some(p) = rfd::FileDialog::new()
                                        .set_title("选择下载目录")
                                        .pick_folder()
                                    {
                                        self.download_dir = p;
                                        self.save_config();
                                    }
                                }
                            });
                        });
                        
                    // 2. 添加任务卡片
                    egui::Frame::new()
                        .fill(CARD)
                        .corner_radius(egui::CornerRadius::same(12))
                        .stroke(egui::Stroke::new(1.0_f32, BORDER))
                        .inner_margin(egui::Margin::same(16))
                        .show(ui, |ui| {
                            ui.set_width(ui.available_width());
                            ui.horizontal(|ui| {
                                ui.label(egui::RichText::new("📥 添加任务").size(15.0).strong().color(TEXT));
                                
                                // 将“开始下载”按钮放在卡片标题栏右侧
                                ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                                    let start_btn = egui::Button::new(
                                        egui::RichText::new(if self.running { "下载中..." } else { "🚀 开始下载" })
                                            .size(14.0).strong().color(TEXT)
                                    ).min_size(egui::vec2(120.0, 32.0));
                                    
                                    let start_btn = if self.running {
                                        start_btn.fill(BTN)
                                    } else {
                                        start_btn.fill(ACCENT)
                                    };
                                    
                                    if ui.add_enabled(!self.running, start_btn).clicked() {
                                        self.start_all();
                                    }
                                    
                                    ui.add_space(16.0);
                                    
                                    ui.add(
                                        egui::TextEdit::singleline(&mut self.app_id_input)
                                            .desired_width(120.0)
                                            .hint_text("留空=自动识别")
                                            .min_size(egui::vec2(0.0, 28.0))
                                    );
                                    ui.label(egui::RichText::new("AppID").size(13.0).color(DIM));
                                });
                            });
                            
                            ui.add_space(12.0);
                            
                            let re = ui.add(
                                egui::TextEdit::multiline(&mut self.workshop_input)
                                    .desired_rows(3)
                                    .desired_width(f32::INFINITY)
                                    .hint_text("在这里粘贴创意工坊链接或物品 ID (每行一个)\n例: https://steamcommunity.com/sharedfiles/filedetails/?id=2898690113")
                            );
                            
                            if re.lost_focus() && ui.input(|i| i.key_pressed(egui::Key::Enter)) && !self.running {
                                self.start_all();
                                re.request_focus();
                            }
                            
                            let preview = config::parse_workshop_ids_bulk(&self.workshop_input);
                            if !preview.is_empty() {
                                ui.add_space(6.0);
                                ui.label(egui::RichText::new(format!("已识别到 {} 个任务，点击「开始下载」或按回车开始", preview.len())).color(SUCCESS).size(12.0));
                            }
                        });
                });
                
                ui.add_space(24.0);
                
                // ── 下半部分：任务列表 ──
                ui.horizontal(|ui| {
                    ui.label(egui::RichText::new("📋 下载队列").size(16.0).strong().color(TEXT));
                    
                    if !self.tasks.is_empty() {
                        let running_count = self.tasks.iter().filter(|t| t.state == TaskState::Downloading).count();
                        let done_count = self.tasks.iter().filter(|t| matches!(t.state, TaskState::Done)).count();
                        ui.add_space(10.0);
                        ui.label(
                            egui::RichText::new(format!("({} 任务 · {} 进行中 · {} 已完成)", self.tasks.len(), running_count, done_count))
                                .size(13.0)
                                .color(DIM)
                        );
                    }
                });
                ui.add_space(12.0);
                
                egui::Frame::new()
                    .fill(INPUT_BG)
                    .corner_radius(egui::CornerRadius::same(10))
                    .stroke(egui::Stroke::new(1.0_f32, BORDER))
                    .inner_margin(egui::Margin::same(4))
                    .show(ui, |ui| {
                        ui.set_width(ui.available_width());
                        egui::ScrollArea::vertical()
                            .auto_shrink([false, false])
                            .show(ui, |ui| {
                                if self.tasks.is_empty() {
                                    ui.vertical_centered(|ui| {
                                        ui.add_space(60.0);
                                        ui.label(egui::RichText::new("📭").size(40.0));
                                        ui.add_space(10.0);
                                        ui.label(egui::RichText::new("暂无任务").size(16.0).color(DIM));
                                        ui.add_space(6.0);
                                        ui.label(egui::RichText::new("在上方的输入框添加创意工坊链接即可开始下载").size(13.0).color(BORDER));
                                    });
                                    return;
                                }
                                
                                for task in self.tasks.iter_mut() {
                                    task_card(ui, task);
                                }
                            });
                    });
            });
    }
}

fn shorten_path(p: &Path, max: usize) -> String {
    let s = p.display().to_string();
    let chars: Vec<char> = s.chars().collect();
    if chars.len() <= max {
        return s;
    }
    let keep = max / 2 - 1;
    let head: String = chars[..keep].iter().collect();
    let tail: String = chars[chars.len() - keep..].iter().collect();
    format!("{}…{}", head, tail)
}

fn task_card(ui: &mut egui::Ui, task: &mut Task) {
    let is_done = matches!(task.state, TaskState::Done);
    let is_running = task.state == TaskState::Downloading;
    
    let state_color = match &task.state {
        TaskState::Pending => DIM,
        TaskState::Downloading => ACCENT,
        TaskState::Done => SUCCESS,
        TaskState::Failed(_) => ERROR,
    };
    
    let failed_msg = match &task.state {
        TaskState::Failed(e) => Some(e.clone()),
        _ => None,
    };
    
    let progress = (task.progress / 100.0).clamp(0.0f32, 1.0f32);
    let last_line = task.last_line.clone();
    
    let card_height = if is_running { 70.0 } else { 48.0 };
    
    egui::Frame::new()
        .fill(CARD)
        .corner_radius(egui::CornerRadius::same(8))
        .stroke(egui::Stroke::new(1.0_f32, BORDER))
        .inner_margin(egui::Margin::symmetric(14, 10))
        .outer_margin(egui::Margin { bottom: 8, left: 4, right: 4, top: 4 })
        .show(ui, |ui| {
            ui.set_min_size(egui::vec2(ui.available_width(), card_height));
            
            ui.horizontal(|ui| {
                // 左侧图标
                let icon = match &task.state {
                    TaskState::Pending => "⏳",
                    TaskState::Downloading => "⬇️",
                    TaskState::Done => "✅",
                    TaskState::Failed(_) => "❌",
                };
                ui.label(egui::RichText::new(icon).size(16.0).color(state_color));
                
                ui.add_space(4.0);
                
                // 任务信息
                ui.vertical(|ui| {
                    ui.horizontal(|ui| {
                        ui.label(egui::RichText::new(&task.workshop_id).size(14.0).strong().color(TEXT));
                        let app_id_text = if task.app_id.is_empty() { "自动获取 AppID".to_string() } else { format!("AppID: {}", task.app_id) };
                        ui.label(egui::RichText::new(app_id_text).size(12.0).color(DIM));
                    });
                    
                    if is_running {
                        ui.add_space(6.0);
                        ui.horizontal(|ui| {
                            let pb = egui::ProgressBar::new(progress)
                                .desired_width(ui.available_width() - 50.0)
                                .desired_height(6.0)
                                .fill(ACCENT)
                                .show_percentage();
                            ui.add(pb);
                        });
                        
                        if !last_line.is_empty() {
                            ui.add_space(4.0);
                            ui.label(
                                egui::RichText::new(shorten_text(&last_line, 80))
                                    .size(11.0)
                                    .color(DIM)
                            );
                        }
                    }
                });
                
                // 右侧状态文本
                if !is_running {
                    ui.with_layout(egui::Layout::right_to_left(egui::Align::Center), |ui| {
                        if let Some(e) = &failed_msg {
                            ui.label(egui::RichText::new(shorten_text(e, 30)).color(ERROR).size(12.0));
                        } else if is_done {
                            ui.label(egui::RichText::new("已完成").color(SUCCESS).size(12.0).strong());
                        } else {
                            ui.label(egui::RichText::new("排队中").color(DIM).size(12.0));
                        }
                    });
                }
            });
        });
}

fn shorten_text(s: &str, max: usize) -> String {
    let n = s.chars().count();
    if n <= max {
        return s.to_string();
    }
    let kept: String = s.chars().take(max).collect();
    format!("{}…", kept)
}
