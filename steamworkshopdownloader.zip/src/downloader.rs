use serde::{Deserialize, Serialize};
use std::io::{BufRead, BufReader};
use std::path::{Path, PathBuf};
use std::os::windows::process::CommandExt;
use std::process::{Child, Command};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{Receiver, Sender};
use std::sync::{Arc, Mutex};

/// Windows 下启动 steamcmd 时不弹控制台黑窗口
const CREATE_NO_WINDOW: u32 = 0x0800_0000;

/// 单个下载任务的状态
#[derive(Debug, Clone, PartialEq)]
pub enum TaskState {
    /// 排队中
    Pending,
    /// 下载中（进度来自 steamcmd 的 Update state 行）
    Downloading,
    /// 已完成
    Done,
    /// 失败（存错误信息）
    Failed(String),
}

/// 一条下载任务（保留供后续持久化使用；当前 UI 层持有自己的任务行）
#[allow(dead_code)]
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Task {
    /// 创意工坊物品 ID
    pub workshop_id: String,
    /// 目标 AppID（工坊物品所属游戏的 AppID；留空则自动查询）
    pub app_id: String,
    /// 下载目标目录
    pub dest_dir: PathBuf,
    #[serde(default)]
    pub state: TaskStateSerde,
}

/// 便于持久化的简单状态枚举
#[allow(dead_code)]
#[derive(Debug, Clone, Copy, PartialEq, Serialize, Deserialize, Default)]
#[serde(rename_all = "snake_case")]
pub enum TaskStateSerde {
    #[default]
    Pending,
    Downloading,
    Done,
    Failed,
}

#[allow(dead_code)]
impl TaskStateSerde {
    pub fn from_state(s: &TaskState) -> Self {
        match s {
            TaskState::Pending => TaskStateSerde::Pending,
            TaskState::Downloading | TaskState::Failed(_) | TaskState::Done => {
                unreachable!("只在排队阶段序列化")
            }
        }
    }
}

/// 后台线程发回 UI 的消息
pub enum WorkerMsg {
    /// 某个任务进度更新（任务索引, 新状态, 进度0~100, 给用户看的当前日志行）
    Progress(usize, TaskState, f32, String),
    /// 某个任务的 AppID 已自动查询出来（任务索引, AppID）
    AppIdResolved(usize, String),
    /// 全部任务结束
    Finished,
}

/// 走 steamcmd 的下载 worker
pub struct Downloader {
    tx: Sender<WorkerMsg>,
    rx: Receiver<WorkerMsg>,
    /// 当前 steamcmd 进程句柄，停止时用于终止
    child: Arc<Mutex<Option<Child>>>,
    /// 用户点了停止
    cancelled: Arc<AtomicBool>,
}

impl Downloader {
    pub fn new() -> Self {
        let (tx, rx) = std::sync::mpsc::channel();
        Self {
            tx,
            rx,
            child: Arc::new(Mutex::new(None)),
            cancelled: Arc::new(AtomicBool::new(false)),
        }
    }

    /// 后台线程里逐个跑任务；steamcmd 缺失时先自动下载安装
    pub fn start(&self, tasks: Vec<(String, String, PathBuf)>, steamcmd_path: PathBuf) {
        let tx = self.tx.clone();
        let child = Arc::clone(&self.child);
        let cancelled = Arc::clone(&self.cancelled);
        self.cancelled.store(false, Ordering::SeqCst);

        std::thread::spawn(move || {
            if tasks.is_empty() {
                tx.send(WorkerMsg::Finished).ok();
                return;
            }

            // 未检测到 steamcmd：自动从 Steam 官方下载到 exe 旁 steamcmd 目录
            let steamcmd_path = match crate::steamcmd_setup::ensure_steamcmd(
                &steamcmd_path,
                &tx,
                &cancelled,
            ) {
                Ok(p) => p,
                Err(e) => {
                    let msg = if e == "已取消" {
                        None
                    } else {
                        Some(format!("自动获取 steamcmd 失败：{e}（可手动配置路径后重试）"))
                    };
                    if let Some(msg) = msg {
                        for (idx, ..) in tasks.iter().enumerate() {
                            tx.send(WorkerMsg::Progress(
                                idx,
                                TaskState::Failed(msg.clone()),
                                0.0,
                                "失败".into(),
                            ))
                            .ok();
                        }
                    }
                    tx.send(WorkerMsg::Finished).ok();
                    return;
                }
            };

            let steamcmd_dir: PathBuf = steamcmd_path
                .parent()
                .map(Path::to_path_buf)
                .unwrap_or_else(|| PathBuf::from("."));

            // 全新 steamcmd 首次运行需自更新初始化
            ensure_steamcmd_ready(&steamcmd_path, &steamcmd_dir, &tx, &cancelled);
            if cancelled.load(Ordering::SeqCst) {
                tx.send(WorkerMsg::Finished).ok();
                return;
            }

            for (idx, (workshop_id, mut app_id, dest_dir)) in tasks.into_iter().enumerate() {
                if cancelled.load(Ordering::SeqCst) {
                    break;
                }
                // AppID 为空 = 自动识别：向 Steam 公开接口查询物品所属游戏
                if app_id.is_empty() {
                    tx.send(WorkerMsg::Progress(
                        idx,
                        TaskState::Downloading,
                        0.0,
                        "正在查询物品所属游戏的 AppID…".into(),
                    ))
                    .ok();
                    match lookup_app_id(&workshop_id) {
                        Ok(id) => {
                            tx.send(WorkerMsg::AppIdResolved(idx, id.clone())).ok();
                            app_id = id;
                        }
                        Err(e) => {
                            tx.send(WorkerMsg::Progress(
                                idx,
                                TaskState::Failed(format!("自动识别 AppID 失败：{e}（可手动填写 AppID）")),
                                0.0,
                                "失败".into(),
                            ))
                            .ok();
                            continue;
                        }
                    }
                    if cancelled.load(Ordering::SeqCst) {
                        break;
                    }
                }

                tx.send(WorkerMsg::Progress(
                    idx,
                    TaskState::Downloading,
                    0.0,
                    "启动 steamcmd…".into(),
                ))
                .ok();

                let failed = run_one(
                    &workshop_id,
                    &app_id,
                    &dest_dir,
                    idx,
                    &steamcmd_path,
                    &steamcmd_dir,
                    &tx,
                    &child,
                    &cancelled,
                );
                if cancelled.load(Ordering::SeqCst) {
                    break;
                }
                match failed {
                    None => {
                        tx.send(WorkerMsg::Progress(
                            idx,
                            TaskState::Done,
                            100.0,
                            "完成".into(),
                        ))
                        .ok();
                    }
                    Some(msg) => {
                        tx.send(WorkerMsg::Progress(
                            idx,
                            TaskState::Failed(msg),
                            0.0,
                            "失败".into(),
                        ))
                        .ok();
                    }
                }
            }
            tx.send(WorkerMsg::Finished).ok();
        });
    }

    /// 非阻塞收取后台消息，UI 每帧调用
    pub fn poll(&mut self) -> Option<WorkerMsg> {
        self.rx.try_recv().ok()
    }

    /// 终止当前 steamcmd 进程并停止排队任务
    pub fn cancel(&self) {
        self.cancelled.store(true, Ordering::SeqCst);
        if let Ok(mut guard) = self.child.lock() {
            if let Some(c) = guard.as_mut() {
                let _ = c.kill();
            }
            // 槽位里的句柄由运行线程的 wait 移除
        }
    }
}

/// 通过 Steam 公开接口查询创意工坊物品所属游戏的 AppID（无需 API Key）
pub fn lookup_app_id(workshop_id: &str) -> Result<String, String> {
    let resp: serde_json::Value = ureq::post(
        "https://api.steampowered.com/ISteamRemoteStorage/GetPublishedFileDetails/v1/",
    )
    .timeout(std::time::Duration::from_secs(15))
    .send_form(&[("itemcount", "1"), ("publishedfileids[0]", workshop_id)])
    .map_err(|e| format!("网络请求失败: {e}"))?
    .into_json()
    .map_err(|e| format!("解析返回内容失败: {e}"))?;

    let d = &resp["response"]["publishedfiledetails"][0];
    // result == 1 表示成功；9 = 不存在，其余多为已删除/不可见
    if d["result"].as_i64() != Some(1) {
        return Err("物品不存在、已删除或不可见".into());
    }
    match d["consumer_app_id"].as_u64() {
        Some(n) if n > 0 => Ok(n.to_string()),
        _ => Err("接口未返回 AppID".into()),
    }
}

/// steamcmd 初始化标记：首次自更新完成后会生成 steamapps 目录
fn ensure_steamcmd_ready(
    steamcmd_path: &Path,
    steamcmd_dir: &Path,
    tx: &Sender<WorkerMsg>,
    cancelled: &AtomicBool,
) {
    if steamcmd_dir.join("steamapps").exists() {
        return;
    }

    tx.send(WorkerMsg::Progress(
        0,
        TaskState::Downloading,
        0.0,
        "首次运行，正在初始化 steamcmd（自动更新，可能需要一两分钟）…".into(),
    ))
    .ok();

    let Ok(mut child) = Command::new(steamcmd_path)
        .arg("+quit")
        .current_dir(steamcmd_dir)
        .creation_flags(CREATE_NO_WINDOW)
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::null())
        .spawn()
    else {
        return; // 启动失败留给正式下载时报错
    };

    if let Some(stdout) = child.stdout.take() {
        let mut buf = BufReader::new(stdout);
        let mut line = String::new();
        loop {
            if cancelled.load(Ordering::SeqCst) {
                let _ = child.kill();
                break;
            }
            line.clear();
            match buf.read_line(&mut line) {
                Ok(0) => break,
                Ok(_) => {}
                Err(_) => break,
            }
            let l = line.trim_end();
            if !l.is_empty() {
                tx.send(WorkerMsg::Progress(
                    0,
                    TaskState::Downloading,
                    0.0,
                    l.chars().take(80).collect(),
                ))
                .ok();
            }
        }
    }
    let _ = child.wait();

    if steamcmd_dir.join("steamapps").exists() {
        tx.send(WorkerMsg::Progress(
            0,
            TaskState::Downloading,
            0.0,
            "steamcmd 初始化完成".into(),
        ))
        .ok();
    }
}

/// 单次尝试的结果
enum Attempt {
    /// 下载成功并已交付
    Success,
    /// 用户取消
    Cancelled,
    /// steamcmd 提前退出：既无成功行也无错误行（典型于首次运行自更新后直接退出）
    ExitEarly,
    /// 明确失败
    Failed(String),
}

/// 最终失败信息；None = 成功
fn run_one(
    workshop_id: &str,
    app_id: &str,
    dest_dir: &Path,
    idx: usize,
    steamcmd_path: &Path,
    steamcmd_dir: &Path,
    tx: &Sender<WorkerMsg>,
    child_slot: &Mutex<Option<Child>>,
    cancelled: &AtomicBool,
) -> Option<String> {
    for attempt in 0..2 {
        if cancelled.load(Ordering::SeqCst) {
            return Some("已取消".into());
        }
        if attempt > 0 {
            tx.send(WorkerMsg::Progress(
                idx,
                TaskState::Downloading,
                0.0,
                "上次运行无结果，自动重试一次…".into(),
            ))
            .ok();
        }
        match attempt_download(
            workshop_id,
            app_id,
            dest_dir,
            idx,
            steamcmd_path,
            steamcmd_dir,
            tx,
            child_slot,
            cancelled,
        ) {
            Attempt::Success => return None,
            Attempt::Cancelled => return Some("已取消".into()),
            Attempt::Failed(e) => return Some(e),
            Attempt::ExitEarly => continue,
        }
    }
    Some("steamcmd 未报告下载成功（可能物品不可匿名下载、需要登录或 ID 有误）".into())
}

/// 下载一个物品并交付到给定任务目录
fn attempt_download(
    workshop_id: &str,
    app_id: &str,
    dest_dir: &Path,
    idx: usize,
    steamcmd_path: &Path,
    steamcmd_dir: &Path,
    tx: &Sender<WorkerMsg>,
    child_slot: &Mutex<Option<Child>>,
    cancelled: &AtomicBool,
) -> Attempt {
    // 匿名登录 + 下载 + 退出，全部通过命令行参数按序执行，
    // 与手动输入 login anonymous / workshop_download_item 等价
    let args = [
        "+login",
        "anonymous",
        "+workshop_download_item",
        app_id,
        workshop_id,
        "+quit",
    ];

    let mut child = match Command::new(steamcmd_path)
        .args(args)
        .current_dir(steamcmd_dir)
        .creation_flags(CREATE_NO_WINDOW)
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::null())
        .spawn()
    {
        Ok(c) => c,
        Err(e) => return Attempt::Failed(format!("无法启动 steamcmd: {e}")),
    };

    let stdout = match child.stdout.take() {
        Some(s) => s,
        None => return Attempt::Failed("无法读取 steamcmd 输出".into()),
    };

    // 挂到共享槽位，供停止按钮终止
    if let Ok(mut g) = child_slot.lock() {
        *g = Some(child);
    }

    let mut progress = 0.0f32;
    let mut err: Option<String> = None;
    let mut success_line_seen = false;
    let mut buf = BufReader::new(stdout);
    let mut line = String::new();
    loop {
        line.clear();
        match buf.read_line(&mut line) {
            Ok(0) => break, // EOF：进程结束
            Ok(_) => {}
            Err(_) => break,
        }
        let l = line.trim_end();
        if l.is_empty() {
            continue;
        }

        // 进度行形如：Update state (0x61) downloading, progress: 42.5 (12345) / ...
        if let Some(p) = parse_progress(l) {
            progress = p;
        }

        if l.contains("Success. Downloaded item") {
            success_line_seen = true;
        }
        // steamcmd 的失败行有两种：
        //   "ERROR! Download item 123 failed (Timeout)."
        //   "Download item 123 failed (Failure)."
        // 失败原因取自括号：Failure / Timeout / InsufficientPermissions 等
        let fail_reason: Option<String> = if l.contains("Download item") && l.contains("failed (")
        {
            let reason = l
                .split(" failed (")
                .nth(1)
                .unwrap_or("")
                .split(')')
                .next()
                .unwrap_or("")
                .trim()
                .to_string();
            let reason = if reason.is_empty() { "未知".to_string() } else { reason };
            let id = l
                .split("Download item")
                .nth(1)
                .unwrap_or("")
                .split_whitespace()
                .find(|w| w.chars().all(|c| c.is_ascii_digit()) && w.len() > 3)
                .unwrap_or("")
                .to_string();
            Some(if id.is_empty() {
                format!("物品下载失败（{reason}）")
            } else {
                format!(
                    "物品 {id} 下载失败（{reason}）。常见原因：物品不可匿名下载、AppID 有误或临时网络问题"
                )
            })
        } else {
            None
        };
        if l.contains("ERROR!") || l.contains("Not logged on") || l.contains("No subscription") {
            if err.is_none() {
                let msg = l
                    .split_once("ERROR!")
                    .map(|x| x.1.trim())
                    .filter(|s| !s.is_empty())
                    .unwrap_or(l);
                err = Some(msg.chars().take(160).collect());
            }
        }
        if let Some(msg) = fail_reason {
            if err.is_none() {
                err = Some(msg);
            }
        }

        tx.send(WorkerMsg::Progress(
            idx,
            TaskState::Downloading,
            progress,
            l.chars().take(80).collect(),
        ))
        .ok();

        if cancelled.load(Ordering::SeqCst) {
            break;
        }
    }

    // 从槽位移回句柄并等待退出
    let child = child_slot.lock().ok().and_then(|mut g| g.take());
    if let Some(mut c) = child {
        let _ = c.wait();
    }

    if cancelled.load(Ordering::SeqCst) {
        return Attempt::Cancelled;
    }
    if let Some(e) = err {
        return Attempt::Failed(e);
    }
    if !success_line_seen {
        return Attempt::ExitEarly;
    }

    // steamcmd 把内容放在 <steamcmd 目录>/steamapps/workshop/content/<appid>/<id>
    let src = steamcmd_dir
        .join("steamapps")
        .join("workshop")
        .join("content")
        .join(app_id)
        .join(workshop_id);
    if !src.exists() {
        return Attempt::Failed("下载未找到内容目录，steamcmd 输出可能与预期不符".into());
    }

    // 交付：<下载目录>/<AppID>/ 下合并存放该游戏所有 mod 的内容
    //（不再保留物品 ID 这一层数字目录）
    let target = dest_dir.join(app_id);
    match deliver(&src, &target) {
        Ok(()) => Attempt::Success,
        Err(e) => Attempt::Failed(format!("移动/复制下载结果失败: {e}")),
    }
}

/// 优先整体 rename（同盘瞬间完成）；目标目录已存在则把 src 内容逐项合并进去
///（同名文件以新下载的为准覆盖，保证重复/更新下载能刷新内容）
fn deliver(src: &Path, target: &Path) -> std::io::Result<()> {
    if !target.exists() && std::fs::rename(src, target).is_ok() {
        return Ok(());
    }
    merge_dir_contents(src, target)?;
    std::fs::remove_dir_all(src).ok();
    Ok(())
}

/// 把 src 下的条目逐个移入 dst：目录递归合并，同名文件先用新文件替换
///（Windows 下 rename 到已存在的目标会失败，故先移走旧文件；移动不行再复制）
fn merge_dir_contents(src: &Path, dst: &Path) -> std::io::Result<()> {
    std::fs::create_dir_all(dst)?;
    for entry in std::fs::read_dir(src)? {
        let entry = entry?;
        let from = entry.path();
        let to = dst.join(entry.file_name());
        if entry.file_type()?.is_dir() {
            merge_dir_contents(&from, &to)?;
        } else {
            std::fs::remove_file(&to).ok();
            if std::fs::rename(&from, &to).is_err() {
                std::fs::copy(&from, &to)?;
            }
        }
    }
    Ok(())
}

/// 从 "Update state (0x61) downloading, progress: 42.5 (...)" 提取进度
fn parse_progress(line: &str) -> Option<f32> {
    let idx = line.find("progress: ")?;
    let rest = &line[idx + "progress: ".len()..];
    let num: String = rest
        .chars()
        .take_while(|c| c.is_ascii_digit() || *c == '.')
        .collect();
    num.parse::<f32>().ok()
}
