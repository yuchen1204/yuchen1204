use serde::{Deserialize, Serialize};
use std::path::PathBuf;

/// 应用配置，保存在 exe 旁的 config.json
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    /// steamcmd.exe 的路径
    pub steamcmd_path: PathBuf,
    /// 默认下载目录
    pub download_dir: PathBuf,
    /// 最近使用的 app_id 列表（用于下拉提示）
    #[serde(default)]
    pub recent_app_ids: Vec<String>,
}

impl Config {
    pub fn load(path: &std::path::Path) -> Option<Config> {
        let text = std::fs::read_to_string(path).ok()?;
        serde_json::from_str(&text).ok()
    }

    pub fn save(&self, path: &std::path::Path) {
        if let Ok(json) = serde_json::to_string_pretty(self) {
            let _ = std::fs::write(path, json);
        }
    }
}

/// 解析用户输入，提取创意工坊物品 ID。
/// 支持：纯数字；https://steamcommunity.com/sharedfiles/filedetails/?id=XXX 等含 id= 查询参数的链接
pub fn parse_workshop_id(input: &str) -> Option<String> {
    let s = input.trim();
    if s.is_empty() {
        return None;
    }
    // 任意文本里找 id=查询参数（steam 目的地站链接也是这种形式）
    if let Some(id) = extract_query_param(s, "id") {
        return Some(id);
    }
    if s.chars().all(|c| c.is_ascii_digit()) {
        return Some(s.to_string());
    }
    None
}

fn extract_query_param(text: &str, key: &str) -> Option<String> {
    let needle = format!("{key}=");
    let mut start = 0;
    while let Some(pos) = text[start..].find(&needle) {
        let abs = start + pos + needle.len();
        let rest = &text[abs..];
        // 遇到非数字（&、空格、字符串结尾等）即停止
        if let Some(end) = rest.find(|c: char| !c.is_ascii_digit()) {
            let num = &rest[..end];
            if !num.is_empty() {
                return Some(num.to_string());
            }
        } else if !rest.is_empty() {
            return Some(rest.to_string());
        }
        // 数字段为空则继续找下一个出现位置
        let next = rest.find(|c: char| !c.is_ascii_digit()).unwrap_or(rest.len());
        start = abs + next;
    }
    None
}

/// 从多行粘贴文本里提取所有不重复的 ID
pub fn parse_workshop_ids_bulk(input: &str) -> Vec<String> {
    let mut out = Vec::new();
    for line in input.lines() {
        if let Some(id) = parse_workshop_id(line) {
            if !out.contains(&id) {
                out.push(id);
            }
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn plain_numbers() {
        assert_eq!(
            parse_workshop_id("123456"),
            Some("123456".to_string())
        );
    }

    #[test]
    fn filedetails_url() {
        assert_eq!(
            parse_workshop_id(
                "https://steamcommunity.com/sharedfiles/filedetails/?id=2898690113"
            ),
            Some("2898690113".to_string())
        );
    }

    #[test]
    fn url_with_extra_params() {
        assert_eq!(
            parse_workshop_id(
                "https://steamcommunity.com/sharedfiles/filedetails/?id=2898690113&searchtext=foo"
            ),
            Some("2898690113".to_string())
        );
    }

    #[test]
    fn bulk_lines() {
        let ids = parse_workshop_ids_bulk(
            "https://steamcommunity.com/sharedfiles/filedetails/?id=111\n\n222\nid=333&x=1",
        );
        assert_eq!(ids, vec!["111", "222", "333"]);
    }

    #[test]
    fn invalid_inputs() {
        assert_eq!(parse_workshop_id(""), None);
        assert_eq!(parse_workshop_id("abc"), None);
    }
}
